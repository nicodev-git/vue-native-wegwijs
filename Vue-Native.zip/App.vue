<template>
  <setup></setup>
</template>

<script>
import Setup from "./src/boot/setup.vue";
export default {
  components: { Setup }
};
</script>
